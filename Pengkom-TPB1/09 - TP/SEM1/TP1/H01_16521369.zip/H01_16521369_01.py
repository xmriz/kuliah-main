# NIM/NAMA    : 16521369_Ahmad Rizki
# Tanggal     : 4 Oktober 2021
# Deskripsi   : Program yang menuliskan tulisan 'Hello, World!' di layar

# KAMUS
# Belum diperlukan

# Menuliskan tulisan ke layar
print('Hello, World!')
