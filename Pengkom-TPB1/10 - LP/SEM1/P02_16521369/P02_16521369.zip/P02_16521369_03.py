# NIM/NAMA  : 16521369/Ahmad Rizki
# Tanggal   : 27 Oktober 2020
# Deskripsi : 

# KAMUS

# ALGORITMA

# menginput nilai kelipatan dan banyak suku yang diinginkan

# menginput nilai kelipatan dan banyak suku yang ingin dicetak
k = int(input('Masukkan kelipatan : '))
n = int(input('Masukkan suku bilangan : '))
list = []

i = 1

# Membuat kondisi jika banyak suku habis dibagi kelipatan dan tidak
if n % k == 0:
    while k*i <= n:
        for j in range (k*i, (k*i)-k, -1):
            print (j, end =" ")
        i += 1
else:
    pass