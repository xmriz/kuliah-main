# NIM/NAMA  : 16521369/Ahmad Rizki
# Tanggal   : 27 Oktober 2020
# Deskripsi : 

# KAMUS

# ALGORITMA

N = int(input("Masukkan bilangan (N) : "))
c = N
b = N-1
a = N -2
jumlah = 0
