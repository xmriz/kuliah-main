# NIM/NAMA  : 16521369/Ahmad Rizki
# Tanggal   : 17 November 2021
# Deskripsi : 

# KAMUS
# 

# ALGORITMA

def proses(kar1, kar2):
    list = [kar1, kar2]
    hasil = list + list.reverse()

kar1 = input('Masukkan karakter 1: ')
kar2 = input('Masukkan karakter 2: ')
n = int(input('Masukkan nilai n: '))