#ifndef JUMLAH_KONSONAN_VOKAL_H
#define JUMLAH_KONSONAN_VOKAL_H

// Parameter pertama merupakan kalimat
// Parameter kedua merupakan jumlah huruf konsonan
// Parameter ketiga merupakan jumlah huruf vokal
void jumlahKonsonanVokal(char*, int*, int*);

#endif