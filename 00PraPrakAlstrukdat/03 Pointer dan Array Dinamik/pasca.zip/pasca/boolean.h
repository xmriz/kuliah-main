#ifndef BOOLEAH_H
#define BOOLEAH_H
#define boolean unsigned char
#define true 1
#define false 0
#endif